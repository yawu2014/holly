package com.holly.test.decode;

import lombok.Data;

@Data
public class DefineMeta {
    private String content;
}
